ID: {{$product->id}}
Nombre: {{$product->name}}