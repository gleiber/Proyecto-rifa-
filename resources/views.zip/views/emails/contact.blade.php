<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p><strong>Nombre:</strong></table>{!! $name !!}</p>
	<p><strong>Email:</strong>{!! $email !!}</p>
	<p><strong>Mensaje:</strong>{!! $mensaje !!}</p>
</body>
</html>