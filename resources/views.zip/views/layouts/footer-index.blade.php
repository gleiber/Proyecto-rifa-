<section class="mbr-section mbr-section--relative mbr-section--fixed-size" id="contacts2-36" style="background-color: rgb(60, 60, 60);">
    
    <div class="mbr-section__container container">
        <div class="mbr-contacts mbr-contacts--wysiwyg row">
            <div class="col-sm-6">
                <figure class="mbr-figure mbr-figure--wysiwyg mbr-figure--full-width mbr-figure--no-bg">
                    <div class="mbr-figure__map mbr-figure__map--short mbr-google-map">
                        <p class="mbr-google-map__marker" data-coordinates="40.748384,-73.9854792"></p>
                    </div>
                </figure>
            </div>
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-5 col-sm-offset-1">
                        <p class="mbr-contacts__text"><strong>ADDRESS</strong><br>
1234 Street Name<br>
City, AA 99999<br><br>
<strong>CONTACTS</strong><br>
Email: support@mobirise.com<br>
Phone: +1 (0) 000 0000 001<br>
Fax: +1 (0) 000 0000 002</p>
                    </div>
                    <div class="col-sm-6"><p class="mbr-contacts__text"><strong>LINKS</strong></p><ul class="mbr-contacts__list"><li><a href="https://mobirise.com/bootstrap-template/" class="text-gray">Bootstrap one page template</a><a class="mbr-contacts__link text-gray" href="https://mobirise.com/bootstrap-template/"></a></li><li><a href="https://mobirise.com/bootstrap-template/" class="text-gray">Bootstrap basic template</a><a class="mbr-contacts__link text-gray" href="https://mobirise.com/bootstrap-template/"></a></li><li><a href="https://mobirise.com/bootstrap-template/" class="text-gray">Bootstrap gallery template</a></li><li><a href="https://mobirise.com/bootstrap-template/" class="text-gray">Bootstrap responsive template</a></li><li><br></li></ul></div>
                </div>
            </div>
        </div>
    </div>
</section>
<footer class="mbr-section mbr-section--relative mbr-section--fixed-size" id="footer1-37" style="background-color: rgb(68, 68, 68);">
    
    <div class="mbr-section__container container">
        <div class="mbr-footer mbr-footer--wysiwyg row">
            <div class="col-sm-12">
                <p class="mbr-footer__copyright"></p><p>Copyright (c) 2015 Company Name. <a href="https://mobirise.com/bootstrap-template/license.txt" class="text-gray">License</a></p><p></p>
            </div>
        </div>
    </div>
</footer>