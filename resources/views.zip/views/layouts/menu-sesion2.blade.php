<nav class="navbar navbar-fixed-left navbar-minimal animate" role="navigation">
  <div class="navbar-toggler animate">
    <span class="menu-icon"></span>
  </div>
  <ul class="navbar-menu animate">
    <li>
      <a href="#about-us" class="animate">
        <span class="desc animate"> Perfil </span>
        <span class="glyphicon glyphicon-user"></span>
      </a>
    </li>
    <li>
      <a href="#blog" class="animate">
        <span class="desc animate"> Informate, Sigue Estos Pasos! </span>
        <span class="glyphicon glyphicon-info-sign"></span>
      </a>
    </li>
    <li>
      <a href="#contact-us" class="animate">
        <span class="desc animate"> Comentanos, Tu Opinion es Vital! </span>
        <span class="glyphicon glyphicon-comment"></span>
      </a>
    </li>
    <li>
      <a href="#contact-us" class="animate">
        <span class="desc animate"> Busca Tus Ofertas </span>
        <span class="glyphicon glyphicon-search"></span>
      </a>
    </li>
    <li>
      <a href="#contact-us" class="animate">
        <span class="desc animate"> Comprar un Ticket </span>
        <span class=""><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
      </a>
    </li>
  </ul>
</nav>